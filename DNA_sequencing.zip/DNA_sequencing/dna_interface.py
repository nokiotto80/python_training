"""
================================================================================
PROGETTO: Hollywood Forensic DNA Sequencer (HUD Interface)
DATA CREAZIONE: 19 Luglio 2026
ULTIMO AGGIORNAMENTO: 31 Agosto 2026
AUTORI: AI Collaborator & L'Investigatore Forense
AMBIENTE TESTATO: macOS / Anaconda / Spyder (Python 3.12)

--------------------------------------------------------------------------------
CRONOLOGIA VERSIONI E MODIFICHE:
--------------------------------------------------------------------------------
v1.0  - Layout Tkinter di base con Canvas per DNA e Shell di testo.
v2.0  - Implementazione sintesi vocale nativa macOS ('say') e sequenze casuali.
v3.0  - Integrazione audio per i ticchettii della shell.
v4.0  - Rimozione porte COM e simulazione lettore fotonico USB-C.
v5.0  - Multithreading per evitare il congelamento della GUI durante il parlato.
v6.0  - Sostituzione Pygame con 'afplay' nativo per evitare blocchi Spyder.
v7.0  - Integrazione 'tkmacosx' per sbloccare i colori dei bottoni su Mac.
v8.0  - Design HUD "Continuum": bottoni integrati nello sfondo con bordi.
v9.0  - Unificazione dell'elica a 4 colori distinti (A, T, C, G).
v10.0 - Aggiunta flag `self.is_analyzing`: accelerazione elica e pulsazione bottone.
v10.1 - Fix TclError su tkmacosx e bordi bianchi spessi visibili.
v10.2 - Fix freeze/palla arcobaleno su uscita con gestione pulita `sys.exit()`.
v11.0 - Aggiunta esportazione PDF avanzata con Progress Bar HUD.
v12.0 - Comparazione CIA/FBI con scissione elica DNA ed esito casuale gigante.
v12.1 - Implementata disattivazione preventiva dei bottoni durante le analisi.
v12.2 (CORRENTE) - FIX DEFINITIVO FREEZE POST-POPUP:
       - Eliminati i blocchi modal aggressivi (`grab_set`) sulle finestre Toplevel.
       - Sincronizzati gli aggiornamenti della GUI dal Thread alla Main Loop 
         tramite `root.after()` per evitare Deadlock dello Scheduler Tkinter.
       - Aggiunto svuotamento della coda eventi (`update_idletasks`) alla 
         chiusura dei pop-up.
================================================================================
"""

import os
import random
import sys
import threading
import time
import math
import tkinter as tk

# Caricamento sicuro tkmacosx per gestione bordi e sfondi su Mac
USE_TKMAC = False
try:
    from tkmacosx import Button as MacButton
    USE_TKMAC = True
except ImportError:
    MacButton = tk.Button
    print("[AVVISO] 'tkmacosx' non rilevato. Verrà usato Tkinter standard.")

IS_MAC = sys.platform == "darwin"
SOUND_FILE = "beep2.wav"

def parla_mac(testo):
    """Sintesi vocale nativa macOS (Voce italiana Alice) in background."""
    if IS_MAC:
        os.system(f'say -v Alice "{testo}" &')
    else:
        print(f"[VOCE SIMULATA]: {testo}")

def riproduci_beep():
    """Audio ultra-leggero via afplay senza blocchi di thread."""
    if IS_MAC and os.path.exists(SOUND_FILE):
        os.system(f'afplay "{SOUND_FILE}" &')

class HollywoodForensicUI:

    def __init__(self, root):
        self.root = root
        self.root.title("MATRIX FORENSIC SYSTEMS - DNA SEQUENCER v12.2")

        # Palette Colori Cinema / HUD
        self.bg_color = "#07070c"        # Sfondo Nero/Smeraldo scuro profondo
        self.text_color = "#00ffcc"      # Ciano Neon
        self.accent_color = "#ff3366"    # Rosa/Rosso Alert
        self.font_shell = ("Courier New", 20, "bold")

        # Flag per la gestione dello stato delle simulazioni
        self.is_analyzing = False
        self.is_comparing = False
        self.is_exporting = False
        self.pulse_state = False
        self.pulse_cia_state = False

        # Schermo intero cinematografico
        self.root.attributes("-fullscreen", True)
        self.root.configure(bg=self.bg_color)

        # Chiusura pulita tramite ESC o finestra
        self.root.bind("<Escape>", lambda e: self.chiudi_sistema())
        self.root.protocol("WM_DELETE_WINDOW", self.chiudi_sistema)

        # --- STRUTTURA GUI ---
        
        # Intestazione Superiore HUD
        title_label = tk.Label(
            self.root,
            text="▲ CYBERGENETIC FORENSIC ANALYSIS DIVISION - TOP SECRET ▲",
            font=("Courier New", 24, "bold"),
            bg=self.bg_color,
            fg=self.accent_color,
        )
        title_label.pack(fill=tk.X, pady=20)

        # Frame Principale
        main_frame = tk.Frame(self.root, bg=self.bg_color)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20)

        # 1. SINISTRA: Canvas Animato Elica DNA (Supporta Scissione)
        self.dna_canvas = tk.Canvas(
            main_frame, width=250, height=600, bg="#0d0d1a", 
            highlightthickness=1, highlightbackground=self.text_color
        )
        self.dna_canvas.pack(side=tk.LEFT, fill=tk.Y, padx=10)
        self.dna_angle = 0
        self.animate_dna()

        # 2. CENTRO: Shell di Output
        shell_frame = tk.Frame(main_frame, bg=self.bg_color)
        shell_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10)

        shell_title = tk.Label(
            shell_frame, 
            text="TERMINALE DI SEQUENZIAMENTO ATTIVO: Inserire campione di DNA nello scanner fotonico quantistico collegato al PC", 
            font=("Courier New", 12, "bold"), 
            bg=self.bg_color, 
            fg=self.text_color,
            wraplength=700,
            justify=tk.LEFT
        )
        shell_title.pack(anchor=tk.W, pady=(0, 5))

        self.shell_text = tk.Text(
            shell_frame,
            font=self.font_shell,
            bg="#020205",
            fg=self.text_color,
            insertbackground=self.text_color,
            wrap=tk.WORD,
            state=tk.DISABLED,
            highlightthickness=1,
            highlightbackground="#112244",
        )
        self.shell_text.pack(fill=tk.BOTH, expand=True, pady=5)

        # 3. DESTRA: Pannello Touch con Bottoni HUD
        button_frame = tk.Frame(main_frame, bg=self.bg_color, width=340)
        button_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=10)

        self.status_label = tk.Label(
            button_frame, text="DEVICE: SYSTEM READY\n[USB-C GENETIC SCANNER]", 
            font=("Courier New", 13, "bold"), bg=self.bg_color, fg="#00cc99"
        )
        self.status_label.pack(pady=20)

        # Helper per creare i bottoni HUD con bordo bianco spesso compatibile con macOS
        def crea_bottone_hud(master, text, fg_color, command):
            if USE_TKMAC:
                btn = MacButton(
                    master,
                    text=text,
                    font=("Courier New", 14, "bold"),
                    bg=self.bg_color,
                    fg=fg_color,
                    bordercolor="#ffffff",
                    borderwidth=4,
                    borderless=False,
                    activebackground="#1a000d",
                    activeforeground="#ffffff",
                    command=command
                )
            else:
                btn = tk.Button(
                    master,
                    text=text,
                    font=("Courier New", 14, "bold"),
                    bg=self.bg_color,
                    fg=fg_color,
                    bd=4,
                    relief=tk.SOLID,
                    highlightbackground="#ffffff",
                    highlightthickness=4,
                    command=command
                )
            return btn

        # BOTTONE 1: Inizio Scansione
        self.load_btn = crea_bottone_hud(
            button_frame, 
            "LOAD SAMPLES\n(INIZIA SCANSIONE)", 
            self.accent_color, 
            self.start_sequencing_thread
        )
        self.load_btn.pack(fill=tk.X, pady=12)

        # BOTTONE 2: Esporta PDF
        self.export_pdf_btn = crea_bottone_hud(
            button_frame, 
            "ESPORTA DATA (PDF)\n[GENERATE REPORT]", 
            "#00ffcc", 
            self.esporta_pdf_hud
        )
        self.export_pdf_btn.config(state=tk.DISABLED)
        self.export_pdf_btn.pack(fill=tk.X, pady=12)

        # BOTTONE 3: Confronto Archivio CIA/FBI
        self.export_csv_btn = crea_bottone_hud(
            button_frame, 
            "COMPARA ARCHIVIO CIA\n[GLOBAL SEARCH]", 
            "#00ffcc", 
            self.start_cia_comparison_thread
        )
        self.export_csv_btn.config(state=tk.DISABLED)
        self.export_csv_btn.pack(fill=tk.X, pady=12)

        # BOTTONE USCITA
        exit_btn = crea_bottone_hud(
            button_frame, 
            "CHIUDI SISTEMA (ESC)", 
            "#ffffff", 
            self.chiudi_sistema
        )
        exit_btn.pack(side=tk.BOTTOM, fill=tk.X, pady=20)

    # =========================================================================
    # UTILITY: DISABILITAZIONE/ABILITAZIONE BOTTONI IN MODO SICURO
    # =========================================================================
    def disabilita_tutti_bottoni(self):
        """Blocca l'interazione per prevenire collisioni di comandi."""
        self.load_btn.config(state=tk.DISABLED)
        self.export_pdf_btn.config(state=tk.DISABLED)
        self.export_csv_btn.config(state=tk.DISABLED)

    def riabilita_bottoni_post_analisi(self):
        """Riabilita i bottoni svuotando preventivamente la coda di Tkinter."""
        if self.root.winfo_exists():
            self.root.update_idletasks()
            self.load_btn.config(state=tk.NORMAL)
            self.export_pdf_btn.config(state=tk.NORMAL)
            self.export_csv_btn.config(state=tk.NORMAL)

    # =========================================================================
    # ANIMAZIONE DNA E SCISSIONE DINAMICA
    # =========================================================================
    def animate_dna(self):
        """Genera l'elica 3D. Supporta la scissione dinamica in 2 eliche durante la comparazione."""
        if not self.root.winfo_exists():
            return

        self.dna_canvas.delete("all")
        width = 250
        height = 600

        colore_A = "#00ffcc"
        colore_T = "#00ff66"
        colore_C = "#ff3366"
        colore_G = "#ffff00"

        # Logica del ciclo di fusione/scissione (ogni 3 secondi le eliche si fondono per 1 secondo)
        tempo_attuale = time.time()
        ciclo = tempo_attuale % 4.0
        in_fusione = self.is_comparing and (ciclo > 3.0)

        # Calcolo dei centri delle eliche
        if self.is_comparing and not in_fusione:
            centri_x = [70, 180]  # Due eliche scisse affiancate
            spread = 35           # Raggio ridotto per farle stare nel canvas
            num_points = 20
        else:
            centri_x = [width // 2] # Singola elica al centro
            spread = 65
            num_points = 22

        # Disegno delle eliche (1 o 2 a seconda dello stato)
        for center_x in centri_x:
            for i in range(num_points):
                y = 30 + (i * (height - 60) / num_points)
                phase1 = self.dna_angle + (i * 0.45)
                phase2 = self.dna_angle + (i * 0.45) + math.pi

                x1 = center_x + math.sin(phase1) * spread
                x2 = center_x + math.sin(phase2) * spread

                if i % 2 == 0:
                    self.dna_canvas.create_line(x1, y, x2, y, fill="#223355", width=2)

                c1 = colore_A if i % 2 == 0 else colore_T
                c2 = colore_C if i % 2 == 0 else colore_G

                if math.cos(phase1) < 0:
                    c1 = "#005544"
                if math.cos(phase2) < 0:
                    c2 = "#551122"

                self.dna_canvas.create_oval(x1 - 6, y - 6, x1 + 6, y + 6, fill=c1, outline="")
                self.dna_canvas.create_oval(x2 - 6, y - 6, x2 + 6, y + 6, fill=c2, outline="")

        # Gestione della velocità di rotazione
        if self.is_analyzing or self.is_comparing:
            self.dna_angle += 0.16
            refresh_rate = 10
        else:
            self.dna_angle += 0.05
            refresh_rate = 40

        self.root.after(refresh_rate, self.animate_dna)

    # =========================================================================
    # FUNZIONALITÀ BOTTONE 1: LOAD SAMPLES / SCANSIONE DNA
    # =========================================================================
    def pulse_load_button(self):
        """Fa pulsare il testo del bottone LOAD SAMPLES a 1 Hz."""
        if self.is_analyzing:
            if self.pulse_state:
                self.load_btn.config(
                    font=("Courier New", 16, "bold"),
                    fg="#ffffff",
                    text=">> SCANNING <<\n[ PROCESSING... ]"
                )
            else:
                self.load_btn.config(
                    font=("Courier New", 13, "bold"),
                    fg=self.accent_color,
                    text=">> SCANNING <<\n[ PROCESSING... ]"
                )
            self.pulse_state = not self.pulse_state
            self.root.after(500, self.pulse_load_button)
        else:
            self.load_btn.config(
                font=("Courier New", 14, "bold"),
                fg=self.accent_color,
                text="LOAD SAMPLES\n(INIZIA SCANSIONE)"
            )

    def start_sequencing_thread(self):
        """Avvia l'analisi e blocca temporaneamente gli altri tasti."""
        if self.is_analyzing or self.is_comparing or self.is_exporting:
            return

        self.is_analyzing = True
        self.disabilita_tutti_bottoni()
        self.status_label.config(text="STATUS: SEQUENCING...", fg=self.accent_color)

        self.pulse_load_button()

        thread = threading.Thread(target=self.run_forensic_simulation)
        thread.daemon = True
        thread.start()

    def run_forensic_simulation(self):
        parla_mac("Inizializzazione scansione quantistica del campione genetico. Connessione ai server centrali.")

        self.append_text_to_shell(">>> RILEVAMENTO LETTORE USB-C IN CORSO...\n")
        time.sleep(1.2)
        self.append_text_to_shell(">>> FLUSSO FOTONICO EMESSO. ACQUISIZIONE STRUTTURA CELLULARE...\n")
        time.sleep(1.2)
        self.append_text_to_shell(">>> AVVIO DECRIPTAZIONE DEI NUCLEOTIDI GENERATI DA INPUT COMPLESSO.\n\n")
        time.sleep(0.6)

        basi = ["A", "T", "C", "G"]
        sequenza_casuale = "".join(random.choice(basi) for _ in range(300))

        for i, char in enumerate(sequenza_casuale):
            if not self.root.winfo_exists():
                return
            self.append_text_to_shell(char)
            riproduci_beep()
            
            if (i + 1) % 40 == 0:
                self.append_text_to_shell("\n")
                
            time.sleep(0.02)

        self.append_text_to_shell("\n\n>>> 100% STRUTTURA CROMOSOMICA RICOSTRUITA CON SUCCESSO.\n")
        time.sleep(0.4)

        frase_risultati = "Sequenziamento completato. Ecco i primi risultati grezzi analizzati: "
        lettere_da_leggere = ", ".join(sequenza_casuale[:15])
        frase_finale = (
            frase_risultati
            + lettere_da_leggere
            + " e così via. Operazione terminata. Scegliere dal pannello touch se salvare, esportare o comparare i dati."
        )

        parla_mac(frase_finale)

        self.is_analyzing = False
        if self.root.winfo_exists():
            self.root.after(0, self.riabilita_bottoni_post_analisi)
            self.root.after(0, lambda: self.status_label.config(text="STATUS: ANALYSIS COMPLETE", fg="#00ffcc"))

    # =========================================================================
    # FUNZIONALITÀ BOTTONE 2: ESPORTA PDF (PROGRESS BAR HUD)
    # =========================================================================
    def esporta_pdf_hud(self):
        """Genera un pop-up HUD con Progress Bar a blocchi blu in modalità non-blocking."""
        if self.is_analyzing or self.is_comparing or self.is_exporting:
            return

        if hasattr(self, "export_win") and self.export_win.winfo_exists():
            return

        self.is_exporting = True
        self.disabilita_tutti_bottoni()

        self.export_win = tk.Toplevel(self.root)
        self.export_win.title("FORENSIC EXPORT PROTOCOL")
        self.export_win.geometry("700x350")
        self.export_win.configure(bg="#05050a")
        self.export_win.transient(self.root)

        self.export_win.update_idletasks()
        x = (self.export_win.winfo_screenwidth() // 2) - (700 // 2)
        y = (self.export_win.winfo_screenheight() // 2) - (350 // 2)
        self.export_win.geometry(f"700x350+{x}+{y}")

        lbl_title = tk.Label(
            self.export_win,
            text="▲ EXPORTING DATA TO FORENSIC PDF ▲",
            font=("Courier New", 18, "bold"),
            bg="#05050a",
            fg="#00ccff"
        )
        lbl_title.pack(pady=(30, 20))

        canvas_bar = tk.Canvas(
            self.export_win,
            width=600,
            height=60,
            bg="#020205",
            highlightthickness=2,
            highlightbackground="#00ccff"
        )
        canvas_bar.pack(pady=10)

        lbl_status = tk.Label(
            self.export_win,
            text="INITIALIZING EXPORT ENGINE... 0%",
            font=("Courier New", 14, "bold"),
            bg="#05050a",
            fg="#00ccff"
        )
        lbl_status.pack(pady=15)

        def esegui_progresso():
            totale_blocchi = 10
            spazio_blocco = 560 / totale_blocchi

            for i in range(1, totale_blocchi + 1):
                time.sleep(random.uniform(0.3, 0.6))

                if not self.export_win.winfo_exists():
                    self.is_exporting = False
                    self.root.after(0, self.riabilita_bottoni_post_analisi)
                    return

                x0 = 20 + (i - 1) * spazio_blocco + 3
                y0 = 10
                x1 = 20 + i * spazio_blocco - 3
                y1 = 50
                canvas_bar.create_rectangle(x0, y0, x1, y1, fill="#00aaff", outline="#00ffff", width=2)

                percentuale = i * 10
                lbl_status.config(text=f"COMPILING CHROMOSOME MAP... {percentuale}%")
                riproduci_beep()

            time.sleep(0.3)
            
            canvas_bar.pack_forget()
            lbl_status.pack_forget()
            lbl_title.pack_forget()

            lbl_success = tk.Label(
                self.export_win,
                text="✔ EXPORT SUCCESSFUL!\n\nFILE SAVED IN FORMAT:\n[ PDF_FORENSIC_GENOMIC_REPORT.PDF ]",
                font=("Courier New", 20, "bold"),
                bg="#05050a",
                fg="#00ff66",
                justify=tk.CENTER
            )
            lbl_success.pack(pady=(40, 20))

            parla_mac("Esportazione completata. File PDF salvato con successo.")

            def chiudi_export():
                self.export_win.destroy()
                self.export_win.update_idletasks()
                self.is_exporting = False
                self.riabilita_bottoni_post_analisi()

            btn_close = tk.Button(
                self.export_win,
                text="[ OK / CLOSE ]",
                font=("Courier New", 14, "bold"),
                bg="#00ff66",
                fg="#000000",
                bd=3,
                relief=tk.SOLID,
                command=chiudi_export
            )
            btn_close.pack(pady=10)

        threading.Thread(target=esegui_progresso, daemon=True).start()

    # =========================================================================
    # FUNZIONALITÀ BOTTONE 3: COMPARA ARCHIVIO CIA / US CLOUD SEARCH
    # =========================================================================
    def pulse_cia_button(self):
        """Fa pulsare il tasto COMPARA ARCHIVIO CIA in rosso brillante durante la ricerca."""
        if self.is_comparing:
            if self.pulse_cia_state:
                self.export_csv_btn.config(
                    font=("Courier New", 15, "bold"),
                    fg="#ffffff",
                    text=">> SEARCHING <<\n[ GLOBAL CLOUD ]"
                )
            else:
                self.export_csv_btn.config(
                    font=("Courier New", 13, "bold"),
                    fg=self.accent_color,
                    text=">> SEARCHING <<\n[ GLOBAL CLOUD ]"
                )
            self.pulse_cia_state = not self.pulse_cia_state
            self.root.after(500, self.pulse_cia_button)
        else:
            self.export_csv_btn.config(
                font=("Courier New", 14, "bold"),
                fg="#00ffcc",
                text="COMPARA ARCHIVIO CIA\n[GLOBAL SEARCH]"
            )

    def start_cia_comparison_thread(self):
        """Avvia la comparazione e disabilita gli altri tasti."""
        if self.is_analyzing or self.is_comparing or self.is_exporting:
            return

        self.is_comparing = True
        self.disabilita_tutti_bottoni()
        self.status_label.config(text="STATUS: SEARCHING CLOUD...", fg=self.accent_color)
        
        self.pulse_cia_button()

        thread = threading.Thread(target=self.run_cia_search_simulation)
        thread.daemon = True
        thread.start()

    def run_cia_search_simulation(self):
        """Esegue la sequenza cinematografica di ricerca negli archivi federali USA."""
        parla_mac("Avvio connessione crittografata con i database governativi statunitensi. Ricerca incrociata in corso.")

        self.shell_text.tag_configure("HEADER_RED", font=("Courier New", 24, "bold"), foreground="#ff3366", justify=tk.CENTER)
        self.shell_text.tag_configure("BULLET_TEXT", font=("Courier New", 17, "bold"), foreground="#00ffcc")

        self.append_text_to_shell("\n\n")
        
        if self.root.winfo_exists():
            self.shell_text.config(state=tk.NORMAL)
            self.shell_text.insert(tk.END, "▲ COMPARAZIONE DNA SEQUENZIATO CON ARCHIVI IN CORSO ▲\n\n", "HEADER_RED")
            self.shell_text.config(state=tk.DISABLED)

        agenzie = [
            "Central Intelligence Agency (CIA)",
            "Federal Bureau of Investigation (FBI)",
            "New York City Police Department (NYPD)",
            "Naval Criminal Investigative Service (NCIS)",
            "National Security Agency (NSA)",
            "Drug Enforcement Administration (DEA)"
        ]

        for agenzia in agenzie:
            if not self.root.winfo_exists():
                return
            
            time.sleep(1.8)
            riproduci_beep()
            
            if self.root.winfo_exists():
                self.shell_text.config(state=tk.NORMAL)
                self.shell_text.insert(tk.END, f"  • QUERYING CLOUD DATABASE: {agenzia}...\n", "BULLET_TEXT")
                self.shell_text.see(tk.END)
                self.shell_text.config(state=tk.DISABLED)

        time.sleep(1.2)

        self.is_comparing = False
        if self.root.winfo_exists():
            self.root.after(0, lambda: self.status_label.config(text="STATUS: MATCHING COMPLETE", fg="#00ffcc"))

        esito_positivo = random.choice([True, False])
        agenzia_trovata = random.choice(agenzie)

        # Invocazione Pop-up delegata in modo sicuro alla Main Thread
        self.root.after(0, lambda: self.mostra_popup_risultato_cia(esito_positivo, agenzia_trovata))

    def mostra_popup_risultato_cia(self, positivo, agenzia):
        """Pop-up HUD modal ad alte prestazioni senza blocchi GUI."""
        if hasattr(self, "cia_win") and self.cia_win.winfo_exists():
            return

        self.cia_win = tk.Toplevel(self.root)
        self.cia_win.title("GLOBAL FORENSIC SEARCH RESULT")
        self.cia_win.geometry("800x450")
        self.cia_win.configure(bg="#05050a")
        self.cia_win.transient(self.root)

        self.cia_win.update_idletasks()
        x = (self.cia_win.winfo_screenwidth() // 2) - (800 // 2)
        y = (self.cia_win.winfo_screenheight() // 2) - (450 // 2)
        self.cia_win.geometry(f"800x450+{x}+{y}")

        if positivo:
            colore_esito = "#00ff66"
            titolo_esito = "✔ COMPARAZIONE RIUSCITA!"
            testo_esito = (
                f"SONO STATE TROVATE EQUIVALENZE SUPERIORI AL 95%\n"
                f"DELL'INTERO GENOMA NEI DATABASE SERVER!\n\n"
                f"MATCHING POSITIVO RILEVATO PRESSO:\n[{agenzia.upper()}]\n\n"
                f"SI PREGA DI CONTATTARE IMMEDIATAMENTE L'ENTE COMPETENTE."
            )
            parla_mac("Attenzione! Comparazione riuscita. Corrispondenza genetica trovata negli archivi federali.")
        else:
            colore_esito = "#ff3366"
            titolo_esito = "✖ NESSUNA CORRISPONDENZA"
            testo_esito = (
                "IL CONFRONTO DEL DNA SEQUENZIATO\n"
                "NON HA RESTITUITO CAMPIONI EQUIVALENTI\n"
                "NEGLI ARCHIVI ANALIZZATI.\n\n"
                "SOGGETTO NON PRESENTE NEI DATABASE FORENSI GOVERNATIVI."
            )
            parla_mac("Comparazione completata. Nessun campione equivalente trovato negli archivi analizzati.")

        lbl_title = tk.Label(
            self.cia_win,
            text=titolo_esito,
            font=("Courier New", 26, "bold"),
            bg="#05050a",
            fg=colore_esito
        )
        lbl_title.pack(pady=(40, 20))

        lbl_text = tk.Label(
            self.cia_win,
            text=testo_esito,
            font=("Courier New", 15, "bold"),
            bg="#05050a",
            fg="#ffffff",
            justify=tk.CENTER
        )
        lbl_text.pack(pady=10)

        def chiudi_popup_cia():
            self.cia_win.destroy()
            self.root.update_idletasks()
            self.riabilita_bottoni_post_analisi()

        btn_close = tk.Button(
            self.cia_win,
            text="[ OK / CONFIRM OPERATIVE MATCH ]",
            font=("Courier New", 16, "bold"),
            bg=colore_esito,
            fg="#000000",
            bd=5,
            relief=tk.SOLID,
            command=chiudi_popup_cia
        )
        btn_close.pack(side=tk.BOTTOM, pady=30, ipadx=20, ipady=10)

    # =========================================================================
    # GESTIONE UTILITY E CHIUSURA PULITA
    # =========================================================================
    def append_text_to_shell(self, text):
        """Inserisce il testo nella shell Tkinter in sicurezza."""
        if self.root.winfo_exists():
            self.shell_text.config(state=tk.NORMAL)
            self.shell_text.insert(tk.END, text)
            self.shell_text.see(tk.END)
            self.shell_text.config(state=tk.DISABLED)

    def chiudi_sistema(self):
        """Chiusura immediata, pulita e a prova di congelamento su Spyder e macOS."""
        self.is_analyzing = False
        self.is_comparing = False
        self.is_exporting = False

        try:
            for after_id in self.root.tk.call('after', 'info'):
                self.root.after_cancel(after_id)
        except Exception:
            pass

        try:
            self.root.quit()
            self.root.destroy()
        except Exception:
            pass

        sys.exit(0)

if __name__ == "__main__":
    root = tk.Tk()
    app = HollywoodForensicUI(root)
    root.mainloop()